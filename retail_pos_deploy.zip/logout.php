<?php
require_once 'core/Session.php';
Session::destroy();
